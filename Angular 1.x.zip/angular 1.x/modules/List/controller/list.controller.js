(function () {
    angular.module('myApp').controller('ListController', ListController);
    ListController.$inject = ["$state"];

    function ListController($state) {
        var _this =this;
        
        _this.ColumnList =[ {name:"Id", attrName:"id", filter:""},
                            {name:"Full Name", attrName:"fullName", filter:"uppercase"},
                            {name:"Date Of Birth", attrName:"dob", filter:"date"},
                            {name:"Income", attrName:"income", filter:"currency"},
                          ];
        
        _this.DataList = [
            {id:1234567, fullName:"test 1", dob:1496899751670, income:10000},
            {id:7894656, fullName:"test 2", dob:976559400000, income:25000},
            {id:2581455, fullName:"test 3", dob:660940200000, income:44000},
            {id:8524856, fullName:"test 4", dob:187554600000, income:20000},
            {id:3899558, fullName:"test 5", dob:1449858600000, income:30000}
        ];
        
        _this.navToDetail = function()
        {
            $state.go("Base.Main.Page1");
        }
    
    }
})();