(function () {
    angular.module('myApp').controller('Page2Controller', Page2Controller);
    Page2Controller.$inject = [];

    function Page2Controller() {
    
    }
})();