(function () {
    angular.module('myApp').controller('Page1Controller', Page1Controller);
    Page1Controller.$inject = [];

    function Page1Controller() {
    
    }
})();