(function () {
    angular.module('myApp').controller('LoginController', LoginController);
    LoginController.$inject = [];

    function LoginController() {
    
    }
})();