(function () {
    angular.module('myApp').controller('HeaderController', HeaderController);
    HeaderController.$inject = [];

    function HeaderController() {
    
    }
})();