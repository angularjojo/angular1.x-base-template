(function () {
    angular.module('myApp').controller('MainController', MainController);
    MainController.$inject = [];
    function MainController() {
    
    }
})();