(function () {
    angular.module('myApp').controller('NavbarController', NavbarController);
    NavbarController.$inject = [];

    function NavbarController() {
    
    }
})();