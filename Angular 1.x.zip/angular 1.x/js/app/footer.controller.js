(function () {
    angular.module('myApp').controller('FooterController', FooterController);
    FooterController.$inject = [];

    function FooterController() {
    
    }
})();