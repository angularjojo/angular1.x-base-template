    (function () {
        angular.module('myApp', ['ui.bootstrap', "ui.router","oc.lazyLoad"]);
        angular.module('myApp').config(function ($stateProvider, $urlRouterProvider, $ocLazyLoadProvider) {

            $stateProvider.state("Base", {
                url: "/Base",
                abstract: true,
                views: {
                    "": {
                        template: '<div class="app-page-wrapper" ng-controller="MainController as main">'+
                                        '<div class="app-page-header" ui-view="page-header"></div>'+
                                        '<div class="app-nav-bar" ui-view="nav-bar"></div>'+
                                        '<div class="app-content-wrapper" ui-view></div>'+
                                        '<div class="app-footer" ui-view="footer"></div>'+
                                 '</div>'
                    }

                },resolve: {  
                          loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                            
                            return $ocLazyLoad.load(['js/app/footer.controller.js', 'js/app/header.controller.js'
                                                    , 'js/app/navbar.controller.js', 'js/app/main.controller.js',
                                                    'js/ui-components/directives.js','js/filter/filters.js']);
                          }]
                        }
            }).state("Base.Main", {
                url: "/Main",
                abstract: true,
                views: {
                    "": {
                        template: '<div ui-view></div>'
                    },
                    "page-header": {
                        templateUrl: "partials/header.html",
                        controller: "HeaderController as header"
                    },
                    "nav-bar": {
                        templateUrl: "partials/navbar.html",
                        controller: "NavbarController as navbar"
                    },
                    "footer": {
                        templateUrl: "partials/footer.html",
                        controller: "FooterController as footer"
                    }
                }
            }).state("Base.Main.Page1", {
                url: "/Page1",
                views: {
                    "": {
                        templateUrl: "modules/Page1/html/page1.html",
                        controller: "Page1Controller as Page1"
                    }
                },
                    resolve: {  
                          loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                            
                            return $ocLazyLoad.load(['modules/Page1/controller/page1.controller.js']);
                          }]
                        }
            }).state("Base.Main.Page2", {
                url: "/Page2",
                views: {
                    "": {
                        templateUrl: "modules/Page2/html/page2.html",
                        controller: "Page2Controller as Page2"
                    }
                },
                    resolve: {  
                          loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                            
                            return $ocLazyLoad.load(['modules/Page2/controller/page2.controller.js']);
                          }]
                        }
            }).state("Base.Main.List", {
                url: "/List",
                views: {
                    "": {
                        templateUrl: "modules/List/html/list.html",
                        controller: "ListController as List"
                    }
                },
                    resolve: {  
                          loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                            
                            return $ocLazyLoad.load(['modules/List/controller/list.controller.js']);
                          }]
                        }
            })
                
                .state("Login", {
                url: "/Login",          
                views: {
                    "": {
                        templateUrl: "modules/Login/html/login.html",
                        controller: "LoginController as Login"
                    }
                },
                    resolve: {
                          loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load(['modules/Login/controller/login.controller.js']);
                          }]
                        }
            });

            $urlRouterProvider.otherwise('Login');

        });
    })();