(function () {
    angular.module("myApp").directive("sidenav", function ($state) {
        /* sidenav directive to render the side navigation*/
        return {
            scope: false,
            replace: true,
            templateUrl: "js/ui-components/templates/sidenav.directive.html",
            link: function (scope, element, attrs) {
                scope.SideNavigationLinks=[{route:'Base.Main.Page1', name:'Page 1'}, {route:'Base.Main.Page2', name:'Page 2'}];
                
                scope.goToPath=function(nav)
                {
                    $state.go(nav.route);
                };
                
                scope.isCurrentState=function(nav)
                {
                    return nav.route == $state.current.name;
                }
                
            }
        };
    })
})();

