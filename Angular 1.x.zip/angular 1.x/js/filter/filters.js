
(function () {
    angular.module("myApp").filter('customFilter', function ($filter) {
  return function (item, filter) {
      var filteredData = item;
      switch(filter)
          {
              case 'uppercase': filteredData = item.toUpperCase(); break;
              case 'currency': filteredData = $filter('currency')(item, "$", 2); break; 
              case 'date': filteredData = $filter('date')(item, "medium"); break;       
          }
      
      return filteredData;   
  };
});
})();